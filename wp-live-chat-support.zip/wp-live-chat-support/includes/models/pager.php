<?php
class TCXPager
{
    public function __construct()
    {
        
    }

    public $rows_per_page;
    public $offset;
    public $total_rows; 
    public $pages_counter;
    public $current_page;

}
?>