var departments_validation_rules = {
    wplc_department_name: {
        required: true
    }
};