var quick_responses_validation_rules = {
    wplc_quick_response_title: {
        required: true
    },
    wplc_quick_response_response: {
        required: true,
    },
    wplc_quick_response_sort: {
        required: true,
        number: true
    },
    wplc_quick_response_status: {
        required: true
    }
};