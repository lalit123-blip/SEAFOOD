=== Wp custom slider ===

Contributors: wpatbest
Tags: custom slider, wpslider,Wp Custom slider,gallery,wp gallery,slide order,custom order slider
Requires at least: 3.0.1
Tested up to: 3.9
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Wp-custom-slider is for implement slider on few clicks and wp-admin settings.

There are three options to put items in slider.

1. Upload image from your computer.
2. Add an youtube video link.
3. Add a page featured image.


And you can reorder the slides as you want.


== Installation ==
Automatic installation through WordPress:

   1. Log-in to your WordPress site.
   2. Hover over Plugins and click Add New.
   3. Under Search type in wp-custom-slider, then click Search Plugins.
   4. In the results page, click Install Now.
   5. Once installed, click Activate Plugin. You're done!

Manual installation:

   1. Download here: http://wordpress.org/plugins/wp-custom-slider/ and unarchive the plugin folder.
   2. Upload the customslider folder to the /wp-content/plugins/ directory.
   3. Go to your WordPress dashboard and navigate to Plugins -> Installed Plugins.
   4. On the Plugin page in your WordPress Administration area, activate the wp-custom-slider plugin.


Use this shortcode to display the slider:

[mainslider]

you can user it on any page,post,custom template or in any widget.

like as: <?php do_shortcode('mainslider'); ?>


You can mail me at ashish.sharma537@gmail.com or add me on skype:dreamashish for any kind of query and support.

Thanks 

== Screenshots ==

1. assets/screenshot-1.png
2. assets/screenshot-2.png
2. assets/screenshot-3.png

 

