var custom_fields_validation_rules = {
    wplc_field_name: {
        required: true
    },
    wplc_field_type: {
        required: true
    },

};