<div class="row mx-2">
    <div class="col-md-12">
        <div class="form-row">
            <div class="form-group col-md-12">
				<?= __( "Your 3CX live chat installation will be ready in a moment." ) ?><br/>
				<?= __( "Please wait..." ) ?>
            </div>
        </div>
    </div>
</div>