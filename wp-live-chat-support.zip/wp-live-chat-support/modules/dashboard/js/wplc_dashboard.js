jQuery(document).ready(function() {
    wplc_setupActiveUsersLabels();
});