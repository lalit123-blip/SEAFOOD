jQuery(document).ready(function(e) {
    wplc_handle_errors("#PageError");
});