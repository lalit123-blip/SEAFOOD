<div class="wrap wplc_wrap">
    <div id="wplc_container">
        <div class="bootstrap-wplc-content">
            <div class="alert alert-danger" role="alert">
                <h4 class="alert-heading"><?= $error->Title ?></h4>
                <p><?= $error->Message ?></p>
                <hr>
                <p class="mb-0"><?= $error->HtmlContent ?></p>
            </div>
        </div>
    </div>
</div>
